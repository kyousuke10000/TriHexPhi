# TriHex Obsidian – Grand Design v1.0
これは金本子竜の叡智体系「TriHex Project」をオブシディアン上に展開するための呼吸型フォルダ構造です。

## フォルダ概要
- 00_INDEX: 総索引・タグ・目次
- 01_MANIFESTO: 哲学書・マニフェスト
- 02_RENSEIGAKU: 錬成学（10環）
- 03_SENTEIGAKU: 先帝学（9力）
- 04_HARMONIA_COUNCIL: 叡智評議会（AI合議）
- 05_TECHNOLOGY: 技術・AI連携
- 06_PRACTICE: 実践・OS群
- 07_ARCHIVES: 記録・旧資料
- 99_SYSTEM: 運用・テンプレート
